#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'app.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()



"""
Paylaştığın bu kod, Django projesi oluşturduğun anda Django tarafından otomatik olarak oluşturulan standart bir dosyadır. Dosyanın adı genelde manage.py olur.

Yani bunu senin sıfırdan yazmana gerek yoktur; django-admin startproject komutunu kullandığında Django bu dosyayı senin için proje klasörüne ekler.

Bu Dosya Ne İşe Yarar?
manage.py, projenin yönetim merkezidir. Terminal üzerinden verdiğin komutları Django'nun anlayacağı dile çevirir. İşte en sık kullandığın bazı komutların arka planında bu dosya çalışır:

python manage.py runserver: Geliştirme sunucusunu başlatır.

python manage.py makemigrations: Veritabanı değişikliklerini hazırlar.

python manage.py migrate: Veritabanı tablolarını oluşturur.

python manage.py createsuperuser: Yönetici paneli için kullanıcı oluşturur.

Kodun İçinde Neler Oluyor?
Kodun yaptığı iş aslında oldukça basittir:

Ayarları Tanımlar: os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'app.settings') satırı, Django'ya "Bu projenin ayar dosyası app klasöründeki settings.py dosyasıdır" der.

Hata Kontrolü: Eğer Django bilgisayarında yüklü değilse veya sanal ortamı (virtualenv) aktif etmeyi unuttuysan sana bir hata mesajı gösterir.

Komutu Çalıştırır: Terminale yazdığın argümanları (runserver gibi) alıp Django'nun ana sistemine iletir.

Özetle: Bu kod Django'nun kendi parçasıdır. Proje ismini (app) değiştirmek dışında bu dosyaya dokunman pek gerekmez. Projeni yönetmek için kullandığın bir "anahtar" gibidir.
"""