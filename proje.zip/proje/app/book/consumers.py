import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import BookClub, ClubMessage

class ClubChatConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        self.club_id = self.scope["url_route"]["kwargs"]["club_id"]
        self.room_group_name = f"club_{self.club_id}"
        self.user = self.scope["user"]
       
        print("WS CONNECT OK")


        # Kullanıcı giriş yapmamışsa
        if not self.user.is_authenticated:
            await self.close()
            return

        # Kulüp üyesi mi?
        is_member = await self.is_member()
        if not is_member:
            await self.close()
            return

        # Odaya ekle
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        print(f"Received raw data: {text_data}")  # 👈 yeni satır
        data = json.loads(text_data)
        message = data.get("message")
        print(f"Parsed message: {message}")      # 👈 yeni satır

        if not message:
            return

        # DB'ye kaydet
        await self.save_message(message)

        # Gruptaki herkese gönder
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                "type": "chat_message",
                "user": self.user.username,
                "message": message,
            }
        )

    async def chat_message(self, event):
        await self.send(text_data=json.dumps({
            "user": event["user"],
            "message": event["message"],
        }))

    # ====== DB METOTLARI ======

    @database_sync_to_async
    def is_member(self):
        return BookClub.objects.filter(
            id=self.club_id,
            members=self.user
        ).exists()

    @database_sync_to_async
    def save_message(self, message):
        ClubMessage.objects.create(
            club_id=self.club_id,
            user=self.user,
            message=message
        )


