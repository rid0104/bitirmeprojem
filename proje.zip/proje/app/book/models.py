from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db.models import Avg
from django.utils.translation import gettext_lazy as _



"""
python manage.py makemigrations
python manage.py migrate
"""


class Author(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

 
class Genre(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Publisher(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name




class Book(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)

    date = models.IntegerField(null=True, blank=True)
    pages = models.IntegerField(null=True, blank=True)
    genre = models.ManyToManyField(Genre, blank=True)
    language = models.CharField(max_length=50, blank=True, null=True)
    publishing = models.CharField(max_length=255)

    summary = models.TextField(blank=True, null=True)
    subjectofthebook = models.TextField( blank=True, null=True)
    image = models.ImageField( upload_to="books/", blank=True, null=True)

    def average_rating(self):
            avg = self.bookrating_set.aggregate(
              Avg('rating')
            )['rating__avg']
            return round(avg, 1) if avg else 0

    def __str__(self):
        return self.title





class UserBook(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    STATUS_CHOICES = (
        ('read', 'Okudum'),
        ('to_read', 'Okunacaklar'),
    )
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'book', 'status')

    def __str__(self):
        return f"{self.user.username} - {self.book.title} ({self.status})"




class Urun(models.Model):
    kitapadi = models.CharField(max_length=255)
    yazar = models.CharField(max_length=255)
    sayfasayisi = models.IntegerField(null=True, blank=True)
    tur = models.ManyToManyField(Genre, blank=True)
    dil = models.CharField(max_length=50, blank=True, null=True)
    yayinevi = models.CharField(max_length=255)
    stok = models.IntegerField(default=0)
    aciklama = models.TextField()
    isbn =  models.BigIntegerField(null=True, blank=True)
    tarih = models.IntegerField(null=True, blank=True)
    indirimlifiyat = models.DecimalField(max_digits=10, decimal_places=2)
    kapakcesiti =models.CharField(max_length=50)
    gorsel = models.ImageField( upload_to="products/", blank=True, null=True)
    fiyat = models.DecimalField(max_digits=10, decimal_places=2)


    
    def __str__(self):
        return self.kitapadi

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # Eklemeniz gereken alan:
    favoriler = models.ManyToManyField(Urun, blank=True, related_name='favorileyen_profiller')

    def __str__(self):
        return self.user.username

    def __str__(self):
        return self.user.username

class Yorum(models.Model):
    urun = models.ForeignKey(Urun, on_delete=models.CASCADE, related_name='yorumlar')
    kullanici = models.ForeignKey(User, on_delete=models.CASCADE)
    icerik = models.TextField()
    olusturma_tarihi = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.kullanici.username} - {self.urun.kitapadi}"




class BookNote(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # EKLENDİ
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name="notes")

    NOTE_TYPES = [
        ("yorum", "Yorum"),
        ("inceleme", "İnceleme"),
        ("eleştiri", "Eleştiri"),
        ("alıntı", "Alıntı"),
    ]
    note_type = models.CharField(max_length=20, choices=NOTE_TYPES)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.book.title} - {self.note_type}"
    
class BookClub(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    members = models.ManyToManyField(User, related_name="bookclubs", blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name="created_clubs")
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    
    def __str__(self):
        return self.name
    


class ClubBooks(models.Model):
    club = models.ForeignKey(BookClub, on_delete=models.CASCADE, related_name="books")
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    reading_days = models.PositiveIntegerField(default=20)
    start_date = models.DateField()
    end_date = models.DateField()
    is_current = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.title} - {self.club.name}"


   



class ClubMessage(models.Model):
    club = models.ForeignKey('BookClub', on_delete=models.CASCADE, related_name='messages')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"{self.user.username}: {self.message[:20]}"










class BookRating(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    book = models.ForeignKey(Book,on_delete=models.CASCADE)
    rating = models.PositiveSmallIntegerField()
    created_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user','book')

    
    def __str__(self):
        return f"{self.user} - {self.book.title} - ({self.rating})"

 

