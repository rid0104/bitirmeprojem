from django.urls import path

from book import views
from . import views
from django.contrib.auth import views as auth_views


app_name = "book"

urlpatterns = [
     path("" , views.index, name='index'),
     path("alisveris/" ,views.alisveris, name='alisveris'),
     path("kitapbilgi/" ,views.kitapbilgi, name='kitapbilgi'),
     path("blog/" ,views.blog, name='blog'),
    path('urundetay/<int:id>/', views.urundetay, name='urundetay'),
    path('favoriekle/<int:id>/', views.favoriekle, name="favoriekle"),
    path('sepetekle/<int:id>/', views.sepetekle, name="sepetekle"),
    path('alisverissepeti/', views.alisverissepeti, name="alisverissepeti"),
    path('favoriler/', views.favoriler, name="favoriler"),
    path("urunsil/<int:id>/", views.urun_sil, name="urun_sil"),
    path("favorisil/<int:id>/", views.favori_sil, name="favori_sil"),
    path("odeme/", views.odeme, name="odeme"),
    path("degerlendirmesil/<int:id>/", views.degerlendirme_sil, name="degerlendirme_sil"),
    path('degerlendirme/', views.degerlendirme, name="degerlendirme"),
    path('add_note/', views.add_note, name='add_note'),
   
    path('hakkında/', views.hakkında, name="hakkında"),
    path("okunankitaplarım/" ,views.okunankitaplarım, name="okunankitaplarım"),
    path("okunacakkitaplarım/" ,views.okunacakkitaplarım, name="okunacakkitaplarım"),
    path("kitapekle/<int:book_id>/<str:status>/", views.kitapekle, name="kitapekle"),
    path("yorum-sil/<int:id>/", views.yorum_sil, name="yorum_sil"),
    path("urun-filtre/", views.urunfiltre, name="urunfiltre"),
    

    path('club/<int:club_id>/', views.club_detail, name='club_detail'),
    path('club/<int:club_id>/join/', views.join_club, name='kulube_katil'),

     path('kitapkulubu/', views.kitapkulubu, name="kitapkulubu"),

    path("rate/<int:book_id>/<int:rating>/", views.rate_book, name="rate_book"),
   

    path("giris/", views.giris, name='giris'),
    path("cikis/",views.logout_view, name='logout'),
    path("kayit/",views.giris2, name='giris2'),






]


