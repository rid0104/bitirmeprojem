
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import Profile 
from django.shortcuts import render, get_object_or_404
from .models import Book
from django.contrib.auth.decorators import login_required
from .models import UserBook,BookRating
from .models import BookClub
from .models import Urun
from .models import BookNote
from .models import BookClub
from django.http import JsonResponse
from datetime import datetime
from .models import  Yorum

def index(request):
    okunacak_sayi = 0
    okunan_sayi = 0
    degerlendirme_sayi = 0

    if request.user.is_authenticated:
        okunacak_sayi = UserBook.objects.filter(
            user=request.user,
            status="to_read"
        ).count()

        okunan_sayi = UserBook.objects.filter(
            user=request.user,
            status="read"
        ).count()

        # TÜM değerlendirmeler (yorum + inceleme + eleştiri + alıntı)
        degerlendirme_sayi = BookNote.objects.filter(
            user=request.user
        ).count()

    return render(request, "book/index.html", {
        "okunan_sayi": okunan_sayi,
        "okunacak_sayi": okunacak_sayi,
        "degerlendirme_sayi": degerlendirme_sayi,
    })


def alisveris(request):
    urunler = Urun.objects.all()
    authors = Urun.objects.values_list("yazar",flat=True).distinct()
    return render(request,'book/books.html' ,{
        'urunler': urunler,
        'authors':authors
})





@login_required
def favoriekle(request, id):
    urun = get_object_or_404(Urun, id=id)
    profile, created = Profile.objects.get_or_create(user=request.user)
    profile.favoriler.add(urun)
    return redirect("book:favoriler")


def sepetekle(request, id):
    urun = get_object_or_404(Urun, id=id)
    sepet = request.session.get("sepet", {})

    # GET parametresinden adet al
    adet = int(request.GET.get("adet", 1))

    if str(id) in sepet:
        sepet[str(id)] += adet
    else:
        sepet[str(id)] = adet

    request.session["sepet"] = sepet
    return redirect("book:alisverissepeti")


@login_required
def favoriler(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    favoriler = profile.favoriler.all()
    return render(request, "book/favoriler.html", {"favoriler": favoriler})


@login_required
def favori_sil(request, id):
    profile = Profile.objects.get(user=request.user)
    urun = get_object_or_404(Urun, id=id)
    profile.favoriler.remove(urun)
    return redirect("book:favoriler")


@login_required
def urun_sil(request, id):
    sepet = request.session.get("sepet", {})

    if str(id) in sepet:
        del sepet[str(id)]

    request.session["sepet"] = sepet
    return redirect("book:alisverissepeti")

@login_required
def alisverissepeti(request):
    sepet = request.session.get("sepet", {})
    
    urunler = []
    toplam = 0

    for urun_id, adet in sepet.items():
        urun = Urun.objects.get(id=urun_id)
        urunler.append({
            "urun": urun,
            "adet": adet,
            "ara_toplam": adet * urun.indirimlifiyat
        })
        toplam += adet * urun.indirimlifiyat

    return render(request, "book/alisverissepeti.html", {
        "urunler": urunler,
        "toplam": toplam
    })
    
def odeme(request):
    current_year = datetime.now().year
    years = range(current_year, current_year + 12)
    months = range(1, 13)

    if request.method == "POST":
        messages.success(request, "Ödeme başarıyla tamamlandı! 🎉")
        return redirect("book:odeme")

    return render(request, "book/odeme.html", {
        "years": years,
        "months": months
    })


def kitapbilgi(request):
    # GET parametresinden id al
    book_id = request.GET.get('id')
    book = None
    if book_id:
        book = get_object_or_404(Book, id=book_id)

    # Veritabanındaki tüm kitaplar (listeleme için)
    all_books = Book.objects.all()

    context = {
        'book': book,
        'all_books': all_books,
    }
    return render(request, 'book/kitapbilgi.html', context)


def hakkında(request):
    return render(request,'book/hakkında.html')

def blog(request):
    return render(request,'book/blog_sayfasi.html')


def degerlendirme(request):
    return render(request,'book/degerlendirme.html')



def  giris2(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        
        if password != confirm_password:
            messages.error(request, "şifreler eşleşmiyor")
            return render(request, 'book/giris2.html')
                         
        if User.objects.filter(username=username).exists():
             messages.error(request, "bu kullanıcı adı zaten alınmış")
             return render(request, 'book/giris2.html')

    
        user = User.objects.create_user(username=username, email=email, password=password)
        Profile.objects.create(user=user)
        
        messages.success(request, "Kayıt başarılı! Giriş yapabilirsiniz.")
    
        return redirect('book:giris')
            
    
    return render(request, 'book/giris2.html')



def  giris(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        remember = request.POST.get('remember') 
        user = authenticate(request, username=username, password=password)

        
        if user is not None:
            login(request, user)
            if remember:
                # 2 hafta boyunca oturumu açık tut
                request.session.set_expiry(1209600)  # saniye cinsinden (2 hafta)
            else:
                # Tarayıcı kapatıldığında oturumu sonlandır
                request.session.set_expiry(0)
            return redirect('book:index')
        
        
        messages.error(request, "kullanıcı adı veya şifre yanlış")
        return render(request, 'book/giris.html')
        
    
    return render(request, 'book/giris.html')


# Çıkış
def logout_view(request):
    logout(request)
    return redirect('book:index')




@login_required
def okunankitaplarım(request):
    book = UserBook.objects.filter(user = request.user, status='read')
    context = {'books': book}
     
    user_ratings = {
        r.book_id:r.rating 
        for r in BookRating.objects.filter(user=request.user)
    }

    context = {'books': book,
              'user_ratings': user_ratings} 
    
    return render(request, 'book/okunankitaplarım.html',context)

                                  

@login_required
def okunacakkitaplarım(request):
    book = UserBook.objects.filter(user = request.user, status='to_read')
    context = {'books': book}

  
    return render(request, 'book/okunacakkitaplarım.html',context)



@login_required
def kitapekle(request, book_id, status):
    book = get_object_or_404(Book, id=book_id)
    UserBook.objects.update_or_create(
        user=request.user, 
        book=book,
        defaults={'status': status}
    )
    if status == 'read':
        return redirect('book:okunankitaplarım')
    elif status == 'to_read':
        return redirect('book:okunacakkitaplarım')
    else:
        return redirect('book:index')




    

def add_note(request):
    if request.method == "POST":
        if not request.user.is_authenticated:
            return redirect("book:giris")

        book_name = request.POST.get("book_name").strip()
        note_type = request.POST.get("note_type")
        text = request.POST.get("text").strip()

        try:
            book = Book.objects.get(title__iexact=book_name)
        except Book.DoesNotExist:
            return render(request, "book/degerlendirme.html", {
                "notes": BookNote.objects.all().order_by('-created_at'),
                "genres": Book.objects.values_list("genre", flat=True).distinct(),
                "authors": Book.objects.values_list("author", flat=True).distinct(),
                "error": f"'{book_name}' adlı kitap bulunamadı."
            })

        BookNote.objects.create(user=request.user, book=book, note_type=note_type, text=text)
        return redirect("book:degerlendirme")

    return redirect("book:degerlendirme")


def degerlendirme(request):
    notes = BookNote.objects.all().order_by('-created_at')

    search = request.GET.get("search")
    genre = request.GET.get("genre")
    author = request.GET.get("author")
    page_min = request.GET.get("page_min")
    page_max = request.GET.get("page_max")
    note_type = request.GET.get("note_type")

    if search:
        notes = notes.filter(book__title__icontains=search)
    if author:
        notes = notes.filter(book__author__icontains=author)
    if genre and genre != "all":
        notes = notes.filter(book__genre__id=genre)
    if page_min:
        notes = notes.filter(book__pages__gte=page_min)
    if page_max:
        notes = notes.filter(book__pages__lte=page_max)
    if note_type and note_type != "all":
        notes = notes.filter(note_type=note_type)

    genres = Book.objects.values_list("genre", flat=True).distinct()
    authors = Book.objects.values_list("author", flat=True).distinct()

    return render(request, "book/degerlendirme.html", {
        "notes": notes,
        "genres": genres,
        "authors": authors,
    })


@login_required
def degerlendirme_sil(request, id):
    # Silinecek değerlendirmeyi al, yoksa 404 dön
    note = get_object_or_404(BookNote, id=id)

    # Sadece değerlendirmeyi ekleyen kullanıcı silebilir
    if note.user == request.user:
        note.delete()

    # Silindikten sonra tüm değerlendirmeler sayfasına yönlendir
    return redirect('book:degerlendirme') 


def urundetay(request, id):
    urun = get_object_or_404(Urun, id=id)
    urunler = Urun.objects.exclude(id=id)[:5]  # diğer ürünler, örneğin 5 tanesini göster
 
    yorumlar = urun.yorumlar.all().order_by('-olusturma_tarihi')  # en son yazılan üstte

    if request.method == 'POST':
        if request.user.is_authenticated:
            icerik = request.POST.get('icerik')
            if icerik:
                Yorum.objects.create(urun=urun, kullanici=request.user, icerik=icerik)
                return redirect('book:urundetay', id=urun.id)
        else:
            return redirect('book:giris')  # giriş yapmamışsa login sayfasına yönlendir

    return render(request, 'book/urundetay.html', {'urun': urun, 'urunler': urunler, 'yorumlar': yorumlar})


@login_required
def yorum_sil(request, id):
    yorum = get_object_or_404(Yorum, id=id)

    if yorum.kullanici == request.user:
        yorum.delete()

    return redirect('book:urundetay', yorum.urun.id)





def kitapkulubu(request):
    clubs = BookClub.objects.filter(is_active=True)
    return render(request, "book/kitapkulubu.html", {"clubs": clubs})


@login_required
def club_detail(request, club_id):
    club = get_object_or_404(BookClub, id=club_id)

    # Kulüp üyeleri
    members = club.members.all()

    # Bu ayki kitap
    current_book = club.books.filter(is_current=True).first()

    # Geçmiş kitaplar
    past_books = club.books.filter(is_current=False).order_by('-start_date')

    # Kulüp mesajları (son 50 mesaj)
    messages = club.messages.all().order_by('created_at')[:50]

    context = {
        'club': club,
        'current_book': current_book,
        'past_books': past_books,
        'messages': messages,
        'members': members,
    }
    return render(request, 'book/kitapkulubudetay.html', context)


@login_required
def join_club(request, club_id):
    club = get_object_or_404(BookClub, id=club_id)

    if request.method == 'POST':
        club.members.add(request.user)
        return redirect('book:club_detail', club_id=club.id)

    return redirect('book:kitapkulubudetay')



def urunfiltre(request):
    urunler = Urun.objects.all()
     
    authors = Urun.objects.values_list("yazar", flat=True).distinct()

    search = request.GET.get("search")
    price_min = request.GET.get("price_min")
    price_max = request.GET.get("price_max")
    author = request.GET.get("author")

    # Kitap adı
    if search:
        urunler = urunler.filter(kitapadi__icontains=search)

    # Fiyat
    if price_min:
        urunler = urunler.filter(indirimlifiyat__gte=price_min)

    if price_max:
        urunler = urunler.filter(indirimlifiyat__lte=price_max)

    if author:
        urunler = urunler.filter(yazar__icontains=author)

    


    print("YAZARLAR >>>", authors)  # 👈 ÇOK ÖNEMLİ
  
    context = {
        "urunler": urunler,
        "authors": authors,
    }


    return render(request, "book/books.html", context)




@login_required
def rate_book(request, book_id, rating) :

    if BookRating.objects.filter(user=request.user,  book_id=book_id).exists():
           return JsonResponse({"error": "Bu kitaba zaten oy verdiniz!"}, status=400)

    # Oy yoksa kaydet

    BookRating.objects.create(user=request.user, book_id=book_id, rating = rating)
    return JsonResponse({"success": "Oy başarıyla kaydedildi!"})




