from django.contrib import admin
from .models import BookClub, ClubBooks
from .models import Book,Urun, Author, Genre, Publisher



@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ("title", "author", "date", "publishing")

    # Liste veya tuple OLMAK ZORUNDA
    search_fields = ["title"]      # liste ✔
    filter_horizontal = ["genre"]  # liste ✔

    list_filter = ("author", "publishing", "genre")




@admin.register(Urun)
class UrunAdmin(admin.ModelAdmin):
    list_display = ("kitapadi", "yazar", "tarih", "yayinevi", "stok", "fiyat")
    search_fields = ["kitapadi", "yazar"]
    filter_horizontal = ["tur"]
    list_filter = ("yazar", "yayinevi", "tur", "kapakcesiti")

admin.site.register(Author)
admin.site.register(Genre)
admin.site.register(Publisher)



@admin.register(BookClub)
class BookClubAdmin(admin.ModelAdmin):
    list_display = ("name", "created_by", "is_active", "created_at")
    search_fields = ("name",)
    filter_horizontal = ("members",)


@admin.register(ClubBooks)
class ClubBooksAdmin(admin.ModelAdmin):
    list_display = ("title", "club", "author", "reading_days", "start_date", "end_date", "is_current")
    list_filter = ("club", "is_current", "start_date")
    search_fields = ("title", "author")
    actions = ["make_current"]

    # Sadece seçili kitabı aktif yapacak action
    def make_current(self, request, queryset):
        if queryset.count() != 1:
            self.message_user(request, "Lütfen sadece bir kitabı aktif olarak seçin.", level="error")
            return
        book = queryset.first()
        # Aynı kulüpteki diğer kitapları pasif yap
        book.club.books.update(is_current=False)
        book.is_current = True
        book.save()
        self.message_user(request, f"{book.title} artık aktif kitap olarak ayarlandı.")

    make_current.short_description = "Seçili kitabı AKTİF yap"

    # Admin listesinde “Geçmiş Kitaplar” ve “Aktif Kitap” blokları
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        # opsiyonel olarak aktif kitabı önce göster
        return qs.order_by('-is_current', 'start_date')





