import os
from django.core.asgi import get_asgi_application
"""bundan sonraki kurulumlar chat ksımı için benim eklediklerim"""
from channels.routing import ProtocolTypeRouter,URLRouter
from channels.auth import AuthMiddlewareStack
from channels.security.websocket import AllowedHostsOriginValidator

"""bu ilk satır zaten mevcut"""
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "app.settings")  
django_asgi_app = get_asgi_application()

import book.routing  
application = ProtocolTypeRouter({
    "http": django_asgi_app,
   "websocket": AllowedHostsOriginValidator(
        AuthMiddlewareStack(
            URLRouter(book.routing.websocket_urlpatterns))
   )
})

