
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
"""
from django.contrib import admin
from django.urls import path

urlpatterns = [
    path('admin/', admin.site.urls),
]

sadece bunlar djangodan gelen.
"""

urlpatterns = [
    path('admin/', admin.site.urls),
        path( 'password-reset/', auth_views.PasswordResetView.as_view(  template_name='book/password_reset.html'
        ),
        name='password_reset'
    ),
    path(
        'password-reset/done/',
        auth_views.PasswordResetDoneView.as_view(
            template_name='book/password_reset_done.html'
        ),
        name='password_reset_done'
    ),
    path(
        'reset/<uidb64>/<token>/',
        auth_views.PasswordResetConfirmView.as_view(
            template_name='book/password_reset_confirm.html'
        ),
        name='password_reset_confirm'
    ),
    path(
        'reset/done/',
        auth_views.PasswordResetCompleteView.as_view(
            template_name='book/password_reset_complete.html'
        ),
        name='password_reset_complete'
    ),

       path(
        'password-change/',
        auth_views.PasswordChangeView.as_view(
            template_name='book/password_change.html',
            success_url='/password-change/done/'  # işlem sonrası yönlendirme
        ),
        name='password_change'
    ),

    # Şifre başarıyla değişti sayfası
    path(
        'password-change/done/',
        auth_views.PasswordChangeDoneView.as_view(
            template_name='book/password_change_done.html'
        ),
        name='password_change_done'
    ),



    path("", include("book.urls")),
    
]

if settings.DEBUG:

    
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)




