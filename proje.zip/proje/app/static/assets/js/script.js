window.onscroll = () =>{
    if(window.scrollY > 80){
        document.querySelector('.header1 .header-2').classList.add('active');
    }else{
          document.querySelector('.header1 .header-2').classList.remove('active');
    }
}


    var swiper = new Swiper(".book-slider", {
    loop:true,
    centeredSlides: true,
    autoplay: {
        delay: 9500,
        disableOnInteraction: false,
    },
    

      slidesPerView: 1,
      spaceBetween: 10,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      breakpoints: {
        0: {
          slidesPerView: 1,
          
        },
        768: {
          slidesPerView: 2,
          
        },
        1024: {
          slidesPerView: 3,
          
        },
      },
    });
  